function hola(){
	alert("Hola");
}