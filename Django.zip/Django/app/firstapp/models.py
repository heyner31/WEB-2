from django.db import models

# Create your models here.



#from rest_framework import serializers

#class PaymentSerializer(serializers.Serializer):
    #amount = serializers.IntegerField(required=True, min_value=0)
    #name = serializers.CharField(required=True, max_length=128)
    #type = serializers.IntegerField(required=True, min_value=0)

#class ValidateFormSerializer(serializers.Serializer):
    #var1 = serializers.CharField(required=True, max_length=250)
    #var2 = serializers.CharField(required=True, max_length=250)
    #payments = serializers.ListField(child=PaymentSerializer)
